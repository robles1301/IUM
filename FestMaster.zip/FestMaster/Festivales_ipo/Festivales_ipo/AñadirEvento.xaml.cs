﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Festivales_ipo.ClaseDatos;
using Microsoft.Win32;

namespace Festivales_ipo
{
    /// <summary>
    /// Lógica de interacción para AñadirEvento.xaml
    /// </summary>
    public partial class AñadirEvento : Window
    {
        private Evento eventoOriginal;
        private Dictionary<string, decimal> preciosEntradas = new Dictionary<string, decimal>();
        private BitmapImage imagenCartel;                           
        private List<Artista> artistasDisponibles;
        private Usuario usuarioActual;



        public AñadirEvento()
        {
            InitializeComponent();
            Fecha.SelectedDate = DateTime.Today;
        }

        public AñadirEvento(Evento evento, List<Artista> todosLosArtistas, Usuario usuario, bool esModificacion)
        {
            InitializeComponent();
            eventoOriginal = evento;
            usuarioActual = usuario;
            ConfigurarMenuUsuario();
            artistasDisponibles = todosLosArtistas;
            RefreshArtistasLists();


            btnAñadir.Content = esModificacion ? "Modificar" : "Añadir";



            txtNombreEvento.Text = evento.Nombre;
            cbEstado.SelectedItem = cbEstado.Items.OfType<ComboBoxItem>().FirstOrDefault(item => item.Content.ToString() == evento.Estado);
            Fecha.SelectedDate = evento.Fecha != default ? evento.Fecha : DateTime.Today;
            txtCiudad.Text = evento.Ciudad;
            txtCodigoPostal.Text = evento.CodigoPostal;
            txtDirección.Text = evento.Direccion;
            txtRedesSociales.Text = evento.RedesSociales;
            txtRutaArchivoVideo.Text = evento.VideoPromocional;
            txtDondeDormir.Text = evento.DondeDormir;
            txtNormas.Text = evento.Normas;
            TxtRutaArchivoCartel.Text = evento.ImagenCartel;


         
            if (evento.PreciosEntradas != null)
            {
                cmbTipoEntrada.Items.Clear();
                foreach (var precio in evento.PreciosEntradas)
                {
                    preciosEntradas[precio.Key] = precio.Value;
                    cmbTipoEntrada.Items.Add(new ComboBoxItem { Content = precio.Key });
                }
            }
          
            if (evento.SponsorsList != null)
            {
                foreach (var sponsor in evento.SponsorsList)
                {
                    lbSponsors.Items.Add(System.IO.Path.GetFileName(sponsor)); 
                }
            }
            if (eventoOriginal.Artistas == null)
                eventoOriginal.Artistas = new List<Artista>();

           
            RefreshArtistasLists();
            cmbTipoEntrada.Items.Clear();
            cmbTipoEntrada.Items.Add(new ComboBoxItem { Content = "VIP" });
            cmbTipoEntrada.Items.Add(new ComboBoxItem { Content = "Normal" });

            if (evento.PreciosEntradas != null)
            {
                foreach (var precio in evento.PreciosEntradas)
                {
                    preciosEntradas[precio.Key] = precio.Value;
                }
            }
        }
            private void RefreshArtistasLists()
        {
            artistasDisponibles = artistasDisponibles ?? new List<Artista>();
            eventoOriginal.Artistas = eventoOriginal.Artistas ?? new List<Artista>();

            var disponibles = artistasDisponibles
                .Where(a => !eventoOriginal.Artistas.Any(x => x.Nombre == a.Nombre))
                .ToList();

            lbArtistasDisponibles.ItemsSource = null;
            lbArtistasDisponibles.ItemsSource = disponibles;
            lbArtistasSeleccionados.ItemsSource = null;
            lbArtistasSeleccionados.ItemsSource = eventoOriginal.Artistas;
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }

        private void btnAñadir_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombreEvento.Text) ||
                cbEstado.SelectedItem == null ||
                Fecha.SelectedDate == null ||
                string.IsNullOrWhiteSpace(txtCiudad.Text) ||
                string.IsNullOrWhiteSpace(txtCodigoPostal.Text) ||
                string.IsNullOrWhiteSpace(txtDirección.Text) ||
                string.IsNullOrWhiteSpace(txtRedesSociales.Text) ||
                string.IsNullOrWhiteSpace(txtDondeDormir.Text) ||
                string.IsNullOrWhiteSpace(txtNormas.Text))
            {
                MessageBox.Show("Por favor, rellene todos los campos obligatorios.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return; 
            }

            if (eventoOriginal != null)
            {
                eventoOriginal.Nombre = txtNombreEvento.Text;
                eventoOriginal.Estado = (cbEstado.SelectedItem as ComboBoxItem)?.Content.ToString();
                eventoOriginal.Fecha = (DateTime)Fecha.SelectedDate;
                eventoOriginal.Ciudad = txtCiudad.Text;
                eventoOriginal.CodigoPostal = txtCodigoPostal.Text;
                eventoOriginal.Direccion = txtDirección.Text;
                eventoOriginal.RedesSociales = txtRedesSociales.Text;
                eventoOriginal.VideoPromocional = txtRutaArchivoVideo.Text;
                eventoOriginal.DondeDormir = txtDondeDormir.Text;
                eventoOriginal.Normas = txtNormas.Text;

                if (ImgCartel.Source != null)
                {
                    eventoOriginal.ImagenCartel = ImgCartel.Source.ToString();
                }

                if (cmbTipoEntrada.SelectedItem is ComboBoxItem selectedItem && decimal.TryParse(txtPrecioEntrada.Text, out decimal precio))
                {
                    string tipoEntrada = selectedItem.Content.ToString();
                    if (eventoOriginal.PreciosEntradas == null)
                    {
                        eventoOriginal.PreciosEntradas = new Dictionary<string, decimal>();
                    }
                    eventoOriginal.PreciosEntradas = new Dictionary<string, decimal>(preciosEntradas);
                }

                ((Dashboard)this.Owner).AgregarEvento(eventoOriginal);
                this.Close();
            }
        }

        





        private void btnSubirCartel_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Archivos de Imagen (*.jpg;*.jpeg;*.png)|*.jpg;*.jpeg;*.png",
                Title = "Seleccionar Cartel"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                string rutaImagen = openFileDialog.FileName;
                TxtRutaArchivoCartel.Text = rutaImagen;

                if (eventoOriginal == null)
                {
                    eventoOriginal = new Evento();
                }
                eventoOriginal.ImagenCartel = rutaImagen;

                BitmapImage bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.UriSource = new Uri(rutaImagen);
                bitmap.CacheOption = BitmapCacheOption.OnLoad;
                bitmap.EndInit();
                ImgCartel.Source = bitmap;
            }
        }




        private void btnSubirSponsor_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Archivos de Imagen (*.jpg;*.jpeg;*.png)|*.jpg;*.jpeg;*.png|Todos los archivos (*.*)|*.*",
                Title = "Selecciona un archivo"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                string rutaCompleta = openFileDialog.FileName;

                string uriCompleta = "file:///" + rutaCompleta.Replace("\\", "/");

                if (eventoOriginal == null)
                {
                    eventoOriginal = new Evento();
                }
                if (eventoOriginal.SponsorsList == null)
                {
                    eventoOriginal.SponsorsList = new List<string>();
                }
                eventoOriginal.SponsorsList.Add(uriCompleta);

                string nombreArchivo = System.IO.Path.GetFileName(rutaCompleta);
                lbSponsors.Items.Add(nombreArchivo);
            }
        }



        private void BtnBorrarSponsor_Click(object sender, RoutedEventArgs e)
        {
            if (lbSponsors.SelectedItem != null)
            {
                lbSponsors.Items.Remove(lbSponsors.SelectedItem);
            }
            else
            {
                MessageBox.Show("Por favor, selecciona un archivo para eliminar.", "Advertencia", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnAñadirPrecio_Click(object sender, RoutedEventArgs e)
        {
            if (cmbTipoEntrada.SelectedItem is ComboBoxItem selectedItem)
            {
                string tipoEntrada = selectedItem.Content.ToString();
                string precioTexto = txtPrecioEntrada.Text;
               

                if (decimal.TryParse(precioTexto, out decimal precio) && precio > 0)
                {
                    preciosEntradas[tipoEntrada] = precio;

                    MessageBox.Show($"El precio para la entrada {tipoEntrada} ha sido establecido en {precio:C}.",
                                     "Precio Añadido",
                                     MessageBoxButton.OK,
                                     MessageBoxImage.Information);

                    
                    txtPrecioEntrada.Text = precio.ToString();

                    
                }
                else
                {
                    MessageBox.Show("Por favor, introduce un precio válido (número positivo).",
                                     "Error",
                                     MessageBoxButton.OK,
                                     MessageBoxImage.Warning);
                }
            }
            else
            {
                MessageBox.Show("Por favor, selecciona un tipo de entrada.",
                                 "Error",
                                 MessageBoxButton.OK,
                                 MessageBoxImage.Warning);
            }
        }


        private void btnBorraVideo_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtRutaArchivoVideo.Text) && txtRutaArchivoVideo.Text != "No se ha seleccionado ningún archivo")
            {
                MessageBoxResult result = MessageBox.Show("¿Estás seguro de que quieres borrar el video seleccionado?",
                                                           "Confirmar eliminación",
                                                           MessageBoxButton.YesNo,
                                                           MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    txtRutaArchivoVideo.Text = "No se ha seleccionado ningún archivo";
                }
            }
            else
            {
                MessageBox.Show("No hay un video seleccionado para borrar.", "Error", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void txtNombreEvento_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                txtCiudad.Focus();
            }
        }

        private void txtCiudad_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                txtCodigoPostal.Focus();
            }
        }

        private void txtCodigoPostal_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                txtDirección.Focus();
            }
        }

        private void txtDirección_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                txtRedesSociales.Focus();
            }
        }

        private void txtRedesSociales_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                txtDondeDormir.Focus();
            }
        }

        private void txtDondeDormir_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                txtNormas.Focus();
            }
        }

        private void txtNormas_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                txtNombreEvento.Focus();
            }
        }

       

        private void btnCargarArchivo_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Archivos de Video (*.mp4;*.avi;*.mkv)|*.mp4;*.avi;*.mkv", 
                Title = "Seleccionar Video Promocional"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                string rutaVideo = openFileDialog.FileName;

                txtRutaArchivoVideo.Text = rutaVideo;

                if (eventoOriginal == null)
                {
                    eventoOriginal = new Evento();
                }

                eventoOriginal.VideoPromocional = rutaVideo;
            }
        }
        

        private void txtPrecioEntrada_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
        private void cmbTipoEntrada_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbTipoEntrada.SelectedItem is ComboBoxItem selectedItem)
            {
                string tipoEntrada = selectedItem.Content.ToString();

                if (preciosEntradas.ContainsKey(tipoEntrada))
                {
                    txtPrecioEntrada.Text = preciosEntradas[tipoEntrada].ToString();
                }
                else
                {
                    txtPrecioEntrada.Text = string.Empty;
                }
            }
        }

        private void lbArtistasDisponibles_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var artista = lbArtistasDisponibles.SelectedItem as Artista;
            if (artista == null) return;

            if (eventoOriginal.Artistas.Any(a => a.Nombre == artista.Nombre))
            {
                MessageBox.Show("El artista ya está asignado al evento.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            eventoOriginal.Artistas.Add(artista);
            RefreshArtistasLists();
        }

        private void lbArtistasSeleccionados_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var artista = lbArtistasSeleccionados.SelectedItem as Artista;
            if (artista == null) return;

            var resultado = MessageBox.Show(
                "¿Desea eliminar este artista del evento?",
                "Confirmación",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );

            if (resultado != MessageBoxResult.Yes)
                return;

            eventoOriginal.Artistas.RemoveAll(a => a.Nombre == artista.Nombre);
            RefreshArtistasLists();
        }
        private void ConfigurarMenuUsuario()
        {
            btnUsuario.ContextMenu = new ContextMenu();

            var panel = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Margin = new Thickness(10),
                HorizontalAlignment = HorizontalAlignment.Center
            };

            var img = new Image
            {
                Source = new BitmapImage(new Uri("perfil-de-usuario.jpg", UriKind.Relative)),
                Width = 80,
                Height = 80,
                Margin = new Thickness(0, 0, 0, 5),
                HorizontalAlignment = HorizontalAlignment.Center
            };

            var txtNombre = new TextBlock
            {
                Text = usuarioActual.nombre,
                FontWeight = FontWeights.Bold,
                FontSize = 14,
                Margin = new Thickness(0, 0, 0, 2),
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center
            };

            var txtCorreo = new TextBlock
            {
                Text = usuarioActual.correo,
                FontSize = 12,
                Foreground = Brushes.Gray,
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center
            };

            panel.Children.Add(img);
            panel.Children.Add(txtNombre);
            panel.Children.Add(txtCorreo);

            var menuItem = new MenuItem
            {
                Header = panel
            };

            btnUsuario.ContextMenu.Items.Add(menuItem);
        }
        private void btnUsuario_Click(object sender, RoutedEventArgs e)
        {
            if (btnUsuario.ContextMenu != null)
            {
                btnUsuario.ContextMenu.PlacementTarget = btnUsuario;
                btnUsuario.ContextMenu.Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom;
                btnUsuario.ContextMenu.IsOpen = true;
            }
        }
    }
}