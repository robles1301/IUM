﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media.Imaging;
using Festivales_ipo.ClaseDatos;
using System.Windows.Controls;
using System.Windows.Media;

namespace Festivales_ipo
{
    public partial class AñadirArtista : Window
    {
        private Artista artista;
        private List<Evento> eventosDisponibles;
        private Usuario usuarioActual;


        public AñadirArtista(Usuario usuario, List<Evento> listaEventos, Artista artistaSeleccionado = null)
        {
            InitializeComponent();
            eventosDisponibles = listaEventos;
            usuarioActual = usuario;
            ConfigurarMenuUsuario();
            lbEventosDisponibles.ItemsSource = eventosDisponibles;

            if (artistaSeleccionado != null)
            {
                artista = artistaSeleccionado;

                if (artista.Eventos == null)
                    artista.Eventos = new List<Evento>();

                txtNombreArtista.Text = artista.Nombre;
                txtApellidos.Text = artista.Apellidos;
                cbxEstado.Text = artista.Estado;
                txtGeneroMusical.Text = artista.generoMusical;
                txtNumero.Text = artista.telefono.ToString();
                txtCorreo.Text = artista.email;
                txtCaché.Text = artista.cache.ToString();
                txtBiografia.Text = artista.Biografia;
                txtRedes.Text = artista.RedSocial;
                lbEventosSeleccionados.ItemsSource = artista.Eventos;

                if (!string.IsNullOrEmpty(artista.foto))
                {
                    ImageControl.Source = new BitmapImage(new Uri(artista.foto));
                }

                this.Title = "Modificar Artista";
                btnModificar.Visibility = Visibility.Visible;
                btnAñadir.Visibility = Visibility.Collapsed;
            }
            else
            {
                artista = new Artista();
                artista.Eventos = new List<Evento>();
                this.Title = "Añadir Artista";
                btnModificar.Visibility = Visibility.Collapsed;
                btnAñadir.Visibility = Visibility.Visible;
            }
        }

        private void RefreshEventosAsignados()
        {
            lbEventosSeleccionados.ItemsSource = null;
            lbEventosSeleccionados.ItemsSource = artista.Eventos;
        }

        private void RefreshEventosDisponibles()
        {
            lbEventosDisponibles.ItemsSource = null;
            lbEventosDisponibles.ItemsSource = eventosDisponibles;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void BtnSubirImg_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Archivos de imagen|*.jpg;*.jpeg;*.png;*.bmp|Todos los archivos|*.*",
                Title = "Selecciona una imagen"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    BitmapImage bitmap = new BitmapImage(new Uri(openFileDialog.FileName));
                    ImageControl.Source = bitmap;
                    lblImginfo.Text = "Imagen subida correctamente.";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al cargar la imagen: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void btnModificar_Click_1(object sender, RoutedEventArgs e)
        {
            if (artista != null)
            {
                artista.Nombre = txtNombreArtista.Text;
                artista.Apellidos = txtApellidos.Text;
                artista.Estado = cbxEstado.Text;
                artista.generoMusical = txtGeneroMusical.Text;
                artista.telefono = int.Parse(txtNumero.Text);
                artista.email = txtCorreo.Text;
                artista.cache = double.Parse(txtCaché.Text);
                artista.Biografia = txtBiografia.Text;
                artista.RedSocial = txtRedes.Text;

                if (ImageControl.Source != null)
                {
                    artista.foto = ImageControl.Source.ToString();
                }
                else
                {
                    artista.foto = null;
                }

                ((GestionArtistas)this.Owner).RefreshList();
                MessageBox.Show("Artista modificado correctamente.", "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close();
            }
            else
            {
                MessageBox.Show("No se pudo modificar el artista.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void lbEventosDisponibles_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            Evento eventoSeleccionado = lbEventosDisponibles.SelectedItem as Evento;
            if (eventoSeleccionado != null)
            {
                if (!artista.Eventos.Any(ev => ev.Nombre == eventoSeleccionado.Nombre))
                {
                    artista.Eventos.Add(eventoSeleccionado);
                    RefreshEventosAsignados();
                }
                else
                {
                    MessageBox.Show("El evento ya está asignado al artista.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }

        private void lbEventosSeleccionados_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            Evento eventoAsignado = lbEventosSeleccionados.SelectedItem as Evento;
            if (eventoAsignado != null)
            {
                if (MessageBox.Show("¿Desea eliminar este evento del artista?", "Confirmación", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    artista.Eventos.Remove(eventoAsignado);
                    RefreshEventosAsignados();
                }
            }

            artista.Eventos.Remove(eventoAsignado);
        }
        private void btnUsuario_Click(object sender, RoutedEventArgs e)
        {
            if (btnUsuario.ContextMenu != null)
            {
                btnUsuario.ContextMenu.PlacementTarget = btnUsuario;
                btnUsuario.ContextMenu.Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom;
                btnUsuario.ContextMenu.IsOpen = true;
            }
        }
        private void ConfigurarMenuUsuario()
        {
            btnUsuario.ContextMenu = new ContextMenu();

            var panel = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Margin = new Thickness(10),
                HorizontalAlignment = HorizontalAlignment.Center
            };

            var img = new Image
            {
                Source = new BitmapImage(new Uri("perfil-de-usuario.jpg", UriKind.Relative)),
                Width = 80,
                Height = 80,
                Margin = new Thickness(0, 0, 0, 5),
                HorizontalAlignment = HorizontalAlignment.Center
            };

            var txtNombre = new TextBlock
            {
                Text = usuarioActual.nombre,
                FontWeight = FontWeights.Bold,
                FontSize = 14,
                Margin = new Thickness(0, 0, 0, 2),
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center
            };

            var txtCorreo = new TextBlock
            {
                Text = usuarioActual.correo,
                FontSize = 12,
                Foreground = Brushes.Gray,
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center
            };

            panel.Children.Add(img);
            panel.Children.Add(txtNombre);
            panel.Children.Add(txtCorreo);

            var menuItem = new MenuItem
            {
                Header = panel
            };

            btnUsuario.ContextMenu.Items.Add(menuItem);
        }
    }
    


}
