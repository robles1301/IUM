﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Festivales_ipo.ClaseDatos;


namespace Festivales_ipo
{
    /// <summary>
    /// Lógica de interacción para Registro.xaml
    /// </summary>
    public partial class Registro : Window


    {
        private bool canClose = false;

        public Registro()
        {
            InitializeComponent();
        }

        private void TxtNewNombreUsuario_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                TxtCorreo.Focus();
            }
        }

        private void TxtCorreo_KeyUp(object sender, KeyEventArgs e)
        {

            TextBox textBox = sender as TextBox;

            if (textBox != null)
            {
                string email = textBox.Text;

                if (!IsValidEmail(email))
                {
                    textBox.BorderBrush = Brushes.Red;

                }
                else
                {
                    textBox.BorderBrush = Brushes.Green;
                }
            }

            if (e.Key == Key.Enter)
            {
                TxtNewContraseña.Focus();
            }
        }
        private bool IsValidEmail(string email)
        {
            string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return Regex.IsMatch(email, emailPattern);
        }
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!canClose)
            {
                e.Cancel = true; 
            }
        }

        private void btnVolverLog_in_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = Application.Current.MainWindow;
            mainWindow.Show();
            canClose = true; 
            this.Close();    
        }


        private void btnRegistrarse_Click(object sender, RoutedEventArgs e)
        {
            if (!IsValidEmail(TxtCorreo.Text))
            {
                MessageBox.Show("Correo inválido", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            
            if (string.IsNullOrEmpty(TxtNewNombreUsuario.Text) ||
                string.IsNullOrEmpty(TxtCorreo.Text) ||
                string.IsNullOrEmpty(TxtNewContraseña.Password) ||
                string.IsNullOrEmpty(TxtConfirmarContraseña.Password))
            {
                MessageBox.Show("No puede dejar campos vacíos", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            
            if (TxtNewContraseña.Password != TxtConfirmarContraseña.Password)
            {
                MessageBox.Show("Las contraseñas no coinciden", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            Usuario nuevoUsuario = new Usuario
            {
                nombre = TxtNewNombreUsuario.Text,
                contraseña = TxtNewContraseña.Password,
                correo = TxtCorreo.Text
            };

            ((MainWindow)this.Owner).agregarUsuario(nuevoUsuario);


            canClose = true;
            MessageBox.Show("Usuario registrado correctamente", "Registro", MessageBoxButton.OK, MessageBoxImage.Information);
            var mainWindow = Application.Current.MainWindow;
            mainWindow.Show();
            this.Close();



        }



        private void TxtNewContraseña_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                TxtConfirmarContraseña.Focus();
            }
        }

        private void TxtConfirmarContraseña_KeyUp(object sender, KeyEventArgs e)
        {


            if (e.Key == Key.Enter)
            {
                btnRegistrarse_Click(sender, e);
            }

        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            
            if (TxtNewContraseña.Password == TxtConfirmarContraseña.Password)
            {
                TxtNewContraseña.BorderBrush = Brushes.Green;
                TxtConfirmarContraseña.BorderBrush = Brushes.Green;
            }
            else
            {
                TxtNewContraseña.BorderBrush = Brushes.Red;
                TxtConfirmarContraseña.BorderBrush = Brushes.Red;
            }
        }

    }
}