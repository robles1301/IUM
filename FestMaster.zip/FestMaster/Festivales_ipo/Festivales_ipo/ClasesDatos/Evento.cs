﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Festivales_ipo
{
    public class Evento
    {
        public Evento()
        {
            Artistas = new List<Artista>();
            SponsorsList = new List<string>();
            PreciosEntradas = new Dictionary<string, decimal>();
        }
        public string Nombre { get; set; }
        public string Estado { get; set; }
        public DateTime Fecha { get; set; }
        public string Ciudad { get; set; }
        public string CodigoPostal { get; set; }
        public string Direccion { get; set; }
        public string RedesSociales { get; set; }
        public string VideoPromocional { get; set; }
        public List<string> SponsorsList { get; set; }
        public string DondeDormir { get; set; }
        public List<Artista> Artistas { get; set; }
        public string Normas { get; set; }
        public Evento EventoModificado { get; set; }

        public override string ToString()
        {
            return Nombre;
        }



        // Para almacenar los precios de las entradas
        public Dictionary<string, decimal> PreciosEntradas { get; set; }
        // Declarada en la clase, por ejemplo:
      


        public string ImagenCartel { get; set; }
        public string DireccionCompleta
        {
            get
            {
                // Construir la dirección en el formato deseado
                return $"{Direccion}, {CodigoPostal}, {Ciudad}";
            }
        }
    }
}
