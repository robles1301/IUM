﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Festivales_ipo
{
    public class Artista
    {
        public string Nombre { get; set; }
        public string Apellidos { get; set; }
        public string Estado { get; set; }
        public string generoMusical { get; set; }
        public int telefono { get; set; }
        public string email { get; set; }
        public double cache { get; set; }
        public string foto { get; set; }
        public string Escenario { get; set; }
        public string Hora { get; set; }
        public DateTime Dia { get; set; }
        public string Biografia { get; set; }
        public string RedSocial { get; set; }
        public string Peticiones { get; set; }
        public List<Evento> Eventos { get; set; }

        public Artista()
        {
            Eventos = new List<Evento>();
        }
        

    }

}
