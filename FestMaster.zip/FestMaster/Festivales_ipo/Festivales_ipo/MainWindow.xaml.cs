﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Festivales_ipo.ClaseDatos;

namespace Festivales_ipo
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        String defaulUser = "admin";
        String defaultPass = "admin";
        private List<Usuario> usuarios = new List<Usuario>();


        private Boolean dashboardIn = false;

        public MainWindow(string text)
        {
            InitializeComponent();
        }

        public void agregarUsuario(Usuario usuario)
        {
            usuarios.Add(usuario);

        }

        public MainWindow()
        {
        }

        private Boolean checkLogin(string user, string pass)
        {
            Boolean result = false;

            if (user.Equals("") || pass.Equals(""))
            {
                MessageBox.Show("No puede dejar campos vacíos", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return result;
            }
            if (user.Equals(defaulUser) && pass.Equals(defaultPass))
            {
                result = true;
            }
            else if (usuarios != null && usuarios.Any(u => u.nombre.Equals(user) && u.contraseña.Equals(pass)))
            {
                result = true;
            }
            else
            {
                MessageBox.Show("Login incorrecto", "Login", MessageBoxButton.OK, MessageBoxImage.Error);
            }



            return result;
        }


        private void MainWindow1_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!dashboardIn)
            {
                if (MessageBox.Show("¿Está seguro de cerrar la ventana?", "Cerrar ventana", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.No)
                {
                    e.Cancel = true;
                }
            }
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            if (checkLogin(TxtUsername.Text, txtPass.Password))
            {
                Usuario usuario = usuarios.FirstOrDefault(u =>
                    u.nombre == TxtUsername.Text && u.contraseña == txtPass.Password);

                if (usuario == null && TxtUsername.Text == "admin")
                {
                    usuario = new Usuario
                    {
                        nombre = "admin",
                        correo = "admin@festmaster.com"
                    };
                }

                dashboardIn = true;
                Dashboard dashboard = new Dashboard(usuario); 
                dashboard.Show();
                this.Close();
            }
        }

        private void TxtUsername_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                txtPass.Focus();
            }

        }

        private void lblRegistry_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.Hide();
            Registro registro = new Registro();
            registro.Owner = this;
            registro.ShowDialog();
        }

            private void lblRegistry_MouseEnter(object sender, MouseEventArgs e)
        {
            lblRegistry.Foreground = Brushes.Blue;
        }

        private void lblRegistry_MouseLeave(object sender, MouseEventArgs e)
        {
            lblRegistry.Foreground = (Brush)new BrushConverter().ConvertFrom("#FF4483FF");
        }

        private void txtPass_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                btnLogin_Click(sender, e);
            }
        }


    }
}