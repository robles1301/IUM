﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using Festivales_ipo.ClaseDatos;


namespace Festivales_ipo
{
    public partial class Dashboard : Window
    {
        private List<Evento> eventos;
        private List<Artista> artistas = new List<Artista>();
        private Usuario usuarioActual;


        public Dashboard(Usuario usuario)
        {
            InitializeComponent();
            usuarioActual = usuario;
            ConfigurarMenuUsuario();
            eventos = new List<Evento>();
            FestivalListBox.ItemsSource = eventos;


            CargarDatosDePrueba();
        }

        private void CargarDatosDePrueba()
        {
            Artista artistaPrueba = new Artista
            {
                Nombre = "David",
                Apellidos = "Bowie",
                Estado = "Activo",
                generoMusical = "Rock",
                telefono = 123456789,
                email = "david.bowie@example.com",
                cache = 50000.0,
                Biografia = "Leyenda del rock, conocido como el camaleón de la música.",
                RedSocial = "instagram.com/davidbowie",
                Eventos = new List<Evento>()
            };
            Artista artistaPrueba2 = new Artista
            {
                Nombre = "Angel",
                Apellidos = "Bowie",
                Estado = "Activo",
                generoMusical = "Rock",
                telefono = 123456789,
                email = "david.bowie@example.com",
                cache = 50000.0,
                Biografia = "Leyenda del rock, conocido como el camaleón de la música.",
                RedSocial = "instagram.com/davidbowie",
                Eventos = new List<Evento>()
            };
            Artista artistaPrueba3 = new Artista
            {
                Nombre = "kike",
                Apellidos = "Bowie",
                Estado = "Activo",
                generoMusical = "Rock",
                telefono = 123456789,
                email = "david.bowie@example.com",
                cache = 50000.0,
                Biografia = "Leyenda del rock, conocido como el camaleón de la música.",
                RedSocial = "instagram.com/davidbowie",
                Eventos = new List<Evento>()
            };
            Artista artistaPrueba4 = new Artista
            {
                Nombre = "Moraga",
                Apellidos = "Bowie",
                Estado = "Activo",
                generoMusical = "Rock",
                telefono = 123456789,
                email = "david.bowie@example.com",
                cache = 50000.0,
                Biografia = "Leyenda del rock, conocido como el camaleón de la música.",
                RedSocial = "instagram.com/davidbowie",
                Eventos = new List<Evento>()
            };


            Evento eventoPrueba = new Evento
            {
                Nombre = "Tomorrowland 2025",
                Estado = "Activo",
                Fecha = new DateTime(2025, 7, 18),
                Ciudad = "Boom",
                CodigoPostal = "2850",
                Direccion = "De Schorre Recreation Area",
                RedesSociales = "https://facebook.com/tomorrowland",
                DondeDormir = "Dreamville Lodges",
                Artistas = new List<Artista>(),
                Normas = "Prohibido entrar con alimentos y bebidas",
                PreciosEntradas = new Dictionary<string, decimal>
            {
                { "VIP", 450.00m },
                { "General", 250.00m }
            },
                
            };

            artistaPrueba.Eventos.Add(eventoPrueba);
            artistaPrueba2.Eventos.Add(eventoPrueba);
            artistaPrueba3.Eventos.Add(eventoPrueba);
            artistaPrueba4.Eventos.Add(eventoPrueba);


            eventoPrueba.Artistas.Add(artistaPrueba);
            eventoPrueba.Artistas.Add(artistaPrueba2);
            eventoPrueba.Artistas.Add(artistaPrueba3);
            eventoPrueba.Artistas.Add(artistaPrueba4);

            artistas.Add(artistaPrueba);
            artistas.Add(artistaPrueba2);
            artistas.Add(artistaPrueba3);
            artistas.Add(artistaPrueba4);

            eventos.Add(eventoPrueba);

            RefreshList();
        }

        public void MostrarImagen(string rutaImagen)
        {
            try
            {
                BitmapImage imagen = new BitmapImage(new Uri(rutaImagen));
                ImgCartel.Source = imagen;  
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar la imagen: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }




        public void AgregarEvento(Evento nuevoEvento)
        {
            if (nuevoEvento != null && !string.IsNullOrEmpty(nuevoEvento.Nombre) && nuevoEvento.Fecha != default(DateTime))
            {
                var eventoExistente = eventos.FirstOrDefault(e => e.Nombre == nuevoEvento.Nombre);

                if (eventoExistente != null)
                {
                    eventos.Remove(eventoExistente);
                }

                eventos.Add(nuevoEvento);
                RefreshList();
            }
            else
            {
                MessageBox.Show("El evento no tiene todos los datos obligatorios.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }




        private void RemoveEvento(Evento evento)
        {
            eventos.Remove(evento);
            RefreshList();
        }



        private void RefreshList()
        {
            FestivalListBox.ItemsSource = null;
            FestivalListBox.ItemsSource = eventos;

            Console.WriteLine("Eventos actuales:");
            foreach (var evento in eventos)
            {
                Console.WriteLine($"Nombre: {evento.Nombre}, Fecha: {evento.Fecha}, Estado: {evento.Estado}");
            }
        }


        private void btnAñadir_Click(object sender, RoutedEventArgs e)
        {
            Evento nuevoEvento = new Evento();
            AñadirEvento añadirEvento = new AñadirEvento(nuevoEvento, artistas, usuarioActual, false);
            añadirEvento.Owner = this;
            añadirEvento.ShowDialog();
        }

        private void FestivalListBox_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Evento eventoSeleccionado = (Evento)FestivalListBox.SelectedItem;

            if (eventoSeleccionado != null)
            {
                VisualizarEvento visualizarEvento = new VisualizarEvento(eventoSeleccionado, usuarioActual);
                visualizarEvento.Owner = this;
                visualizarEvento.ShowDialog();
            }
            else
            {
                MessageBox.Show("No hay un evento seleccionado.", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        public void MostrarCartelesMuestra()
        {
            var eventosDeMuestra = eventos.Where(e => !string.IsNullOrEmpty(e.ImagenCartel)).ToList();
            if (eventosDeMuestra.Any())
            {
                MostrarImagen(eventosDeMuestra.First().ImagenCartel);
            }
            else
            {
                MessageBox.Show("No hay carteles de muestra disponibles.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }


        private void btnEliminar_Click(object sender, RoutedEventArgs e)
        {
            Evento eventoSeleccionado = (Evento)FestivalListBox.SelectedItem;

            if (eventoSeleccionado != null)
            {
                MessageBoxResult resultado = MessageBox.Show(
                    $"¿Estás seguro de que deseas eliminar el evento \"{eventoSeleccionado.Nombre}\"?",
                    "Confirmar eliminación",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (resultado == MessageBoxResult.Yes)
                {
                    RemoveEvento(eventoSeleccionado);
                }
            }
            else
            {
                MessageBox.Show("Selecciona un evento para eliminar.", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void btnModificar_Click(object sender, RoutedEventArgs e)
        {
            if (FestivalListBox.SelectedItem == null)
            {
                MessageBox.Show("Por favor, seleccione un evento para modificar.",
                                "Información",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
                return;
            }

            var eventoSeleccionado = (Evento)FestivalListBox.SelectedItem;
            var win = new AñadirEvento(eventoSeleccionado, artistas, usuarioActual, true);
            win.Owner = this;
            win.ShowDialog();
            RefreshList();
        }



        private void FestivalListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Evento eventoSeleccionado = (Evento)FestivalListBox.SelectedItem;

            if (eventoSeleccionado != null)
            {
                TxtNombreFestival.Text = eventoSeleccionado.Nombre;
                TxtNormas.Text = eventoSeleccionado.Normas;
                TxtFecha.Text = eventoSeleccionado.Fecha.ToString("dd/MM/yyyy");  
                TxtLocalizacion.Text = eventoSeleccionado.DireccionCompleta;  

                if (!string.IsNullOrEmpty(eventoSeleccionado.ImagenCartel))
                {
                    MostrarImagen(eventoSeleccionado.ImagenCartel);
                }
                else
                {
                    ImgCartel.Source = null; 
                }
            }
            else
            {
                TxtNombreFestival.Text = "";
                TxtNormas.Text = "";
                TxtFecha.Text = "";
                TxtLocalizacion.Text = ""; 
                ImgCartel.Source = null;
            }
        }

        private void Button_Click_gestionarArtistas(object sender, RoutedEventArgs e)
        {
            GestionArtistas gestionArtistas = new GestionArtistas(artistas, eventos, usuarioActual);
            gestionArtistas.Owner = this;
            gestionArtistas.ShowDialog();

            artistas = gestionArtistas.ArtistasActualizados; 
            RefreshList(); 
        }

        private void btnUsuario_Click(object sender, RoutedEventArgs e)
        {
            if (btnUsuario.ContextMenu != null)
            {
                btnUsuario.ContextMenu.PlacementTarget = btnUsuario;
                btnUsuario.ContextMenu.Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom;
                btnUsuario.ContextMenu.IsOpen = true;
            }
        }
        private void ConfigurarMenuUsuario()
        {
            btnUsuario.ContextMenu = new ContextMenu();

            var panel = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Margin = new Thickness(10),
                HorizontalAlignment = HorizontalAlignment.Center
            };

            var img = new Image
            {
                Source = new BitmapImage(new Uri("perfil-de-usuario.jpg", UriKind.Relative)),
                Width = 80,
                Height = 80,
                Margin = new Thickness(0, 0, 0, 5),
                HorizontalAlignment = HorizontalAlignment.Center
            };

            var txtNombre = new TextBlock
            {
                Text = usuarioActual.nombre,
                FontWeight = FontWeights.Bold,
                FontSize = 14,
                Margin = new Thickness(0, 0, 0, 2),
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center
            };

            var txtCorreo = new TextBlock
            {
                Text = usuarioActual.correo,
                FontSize = 12,
                Foreground = Brushes.Gray,
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center
            };

            panel.Children.Add(img);
            panel.Children.Add(txtNombre);
            panel.Children.Add(txtCorreo);

            var menuItem = new MenuItem
            {
                Header = panel
            };

            btnUsuario.ContextMenu.Items.Add(menuItem);
        }

        private void ImagenVersion_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            Ayuda ayudaWindow = new Ayuda();
            ayudaWindow.Owner = this;
            ayudaWindow.ShowDialog();
        }
    }

}


