﻿using Festivales_ipo.ClaseDatos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Festivales_ipo
{
    /// <summary>
    /// Lógica de interacción para VisualizarArtista.xaml
    /// </summary>
    public partial class VisualizarArtista : Window
    {
        private Artista _artista;
        private Usuario usuarioActual;

        public VisualizarArtista(Artista artista, Usuario usuario)
        {
            InitializeComponent();
            _artista = artista;
            usuarioActual = usuario;
            ConfigurarMenuUsuario();

            txtNombre.Text = _artista.Nombre;
            txtEstado.Text = _artista.Estado;
            txtGeneroMusical.Text = _artista.generoMusical;
            txtTelefono.Text = _artista.telefono.ToString();
            txtCorreo.Text = _artista.email;
            txtCache.Text = _artista.cache.ToString();
            txtBiografia.Text = _artista.Biografia;
            txtRedSocial.Text = _artista.RedSocial;

            if (!string.IsNullOrEmpty(_artista.foto))
            {
                BitmapImage bitmap = new BitmapImage(new Uri(_artista.foto));
                ImageControl.Source = bitmap; 
            }

            lbEventos.ItemsSource = _artista.Eventos;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }
        private void btnUsuario_Click(object sender, RoutedEventArgs e)
        {
            if (btnUsuario.ContextMenu != null)
            {
                btnUsuario.ContextMenu.PlacementTarget = btnUsuario;
                btnUsuario.ContextMenu.Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom;
                btnUsuario.ContextMenu.IsOpen = true;
            }
        }
        private void ConfigurarMenuUsuario()
        {
            btnUsuario.ContextMenu = new ContextMenu();

            var panel = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Margin = new Thickness(10),
                HorizontalAlignment = HorizontalAlignment.Center
            };

            var img = new Image
            {
                Source = new BitmapImage(new Uri("perfil-de-usuario.jpg", UriKind.Relative)),
                Width = 80,
                Height = 80,
                Margin = new Thickness(0, 0, 0, 5),
                HorizontalAlignment = HorizontalAlignment.Center
            };

            var txtNombre = new TextBlock
            {
                Text = usuarioActual.nombre,
                FontWeight = FontWeights.Bold,
                FontSize = 14,
                Margin = new Thickness(0, 0, 0, 2),
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center
            };

            var txtCorreo = new TextBlock
            {
                Text = usuarioActual.correo,
                FontSize = 12,
                Foreground = Brushes.Gray,
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center
            };

            panel.Children.Add(img);
            panel.Children.Add(txtNombre);
            panel.Children.Add(txtCorreo);

            var menuItem = new MenuItem
            {
                Header = panel
            };

            btnUsuario.ContextMenu.Items.Add(menuItem);
        }
    }
}
