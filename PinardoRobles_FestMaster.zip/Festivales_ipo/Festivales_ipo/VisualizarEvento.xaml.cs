﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Festivales_ipo.ClaseDatos;

namespace Festivales_ipo
{
    /// <summary>
    /// Lógica de interacción para VisualizarEvento.xaml
    /// </summary>
    public partial class VisualizarEvento : Window
    {
        private Evento _evento;
        private Usuario usuarioActual;
        public VisualizarEvento(Evento evento, Usuario usuario)
        {
            InitializeComponent();
            _evento = evento;
            usuarioActual = usuario;
            ConfigurarMenuUsuario();
            AjustarVolumenVideo(0.1);
            // Asignar los datos del evento a los controles de la ventana

            txtNombre.Text = evento.Nombre;
            txtEstado.Text = evento.Estado;
            txtFecha.Text = evento.Fecha.ToString("dd/MM/yyyy");
            txtDireccion.Text = evento.Direccion;
            TxtNormas.Text = evento.Normas;
            TxtDondeDormir.Text = evento.DondeDormir;
            if (!string.IsNullOrWhiteSpace(evento.VideoPromocional))
            {
                try
                {
                    VideoPubli.Source = new Uri(evento.VideoPromocional);
                }
                catch (UriFormatException ex)
                {
                    Debug.WriteLine("Formato de URI inválido para el video promocional: " + ex.Message);
                    VideoPubli.Visibility = Visibility.Collapsed;
                }
            }
            else
            {
                VideoPubli.Visibility = Visibility.Collapsed; // Oculta el reproductor si no hay video
            }

            ImgSponsors.ItemsSource = evento.SponsorsList;
            dgPreciosEntradas.ItemsSource = evento.PreciosEntradas;

            ArtistListBox.ItemsSource = evento.Artistas;


        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void AjustarVolumenVideo(double volumen)
        {
            if (volumen < 0.0 || volumen > 1.0)
            {
                throw new ArgumentOutOfRangeException(nameof(volumen), "El volumen debe estar entre 0.0 y 1.0.");
            }

            VideoPubli.Volume = volumen;
        }

        private void btnUsuario_Click(object sender, RoutedEventArgs e)
        {
            if (btnUsuario.ContextMenu != null)
            {
                btnUsuario.ContextMenu.PlacementTarget = btnUsuario;
                btnUsuario.ContextMenu.Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom;
                btnUsuario.ContextMenu.IsOpen = true;
            }
        }
        private void ConfigurarMenuUsuario()
        {
            btnUsuario.ContextMenu = new ContextMenu();

            var panel = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Margin = new Thickness(10),
                HorizontalAlignment = HorizontalAlignment.Center
            };

            var img = new Image
            {
                Source = new BitmapImage(new Uri("perfil-de-usuario.jpg", UriKind.Relative)),
                Width = 80,
                Height = 80,
                Margin = new Thickness(0, 0, 0, 5),
                HorizontalAlignment = HorizontalAlignment.Center
            };

            var txtNombre = new TextBlock
            {
                Text = usuarioActual.nombre,
                FontWeight = FontWeights.Bold,
                FontSize = 14,
                Margin = new Thickness(0, 0, 0, 2),
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center
            };

         
            var txtCorreo = new TextBlock
            {
                Text = usuarioActual.correo,
                FontSize = 12,
                Foreground = Brushes.Gray,
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center
            };

            panel.Children.Add(img);
            panel.Children.Add(txtNombre);
            panel.Children.Add(txtCorreo);

            var menuItem = new MenuItem
            {
                Header = panel
            };

            btnUsuario.ContextMenu.Items.Add(menuItem);
        }
    }
}