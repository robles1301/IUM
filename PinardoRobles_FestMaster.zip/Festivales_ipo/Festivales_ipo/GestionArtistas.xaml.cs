﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Windows.Media;
using Festivales_ipo.ClaseDatos;

namespace Festivales_ipo
{
    public partial class GestionArtistas : Window
    {
        private List<Artista> artistas;
        private List<Evento> eventos;
        public List<Artista> ArtistasActualizados { get; private set; }
        private Usuario usuarioActual;

        public GestionArtistas(List<Artista> listaArtistas, List<Evento> listaEventos, Usuario usuario)
        {
            InitializeComponent();
            artistas = listaArtistas;
            eventos = listaEventos;
            usuarioActual = usuario;
            ConfigurarMenuUsuario();
            ArtistListBox.ItemsSource = artistas;
            ArtistasActualizados = artistas;
            this.usuarioActual = usuarioActual;
        }
        private void btnUsuario_Click(object sender, RoutedEventArgs e)
        {
            if (btnUsuario.ContextMenu != null)
            {
                btnUsuario.ContextMenu.PlacementTarget = btnUsuario;
                btnUsuario.ContextMenu.Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom;
                btnUsuario.ContextMenu.IsOpen = true;
            }
        }

        public void AgregarArtista(Artista nuevoArtista)
        {
            if (!ArtistasActualizados.Any(a => a.Nombre == nuevoArtista.Nombre))
            {
                ArtistasActualizados.Add(nuevoArtista);
                RefreshList();
            }
        }

        public void RefreshList()
        {
            ArtistListBox.ItemsSource = null;
            ArtistListBox.ItemsSource = artistas;
        }

        private void RemoveArtista(Artista artista)
        {
            artistas.Remove(artista);
            RefreshList();
        }

        private void ArtistListBox_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Artista artistaSeleccionado = (Artista)ArtistListBox.SelectedItem;
            if (artistaSeleccionado != null)
            {
                VisualizarArtista visualizarArtista = new VisualizarArtista(artistaSeleccionado, usuarioActual);
                visualizarArtista.Owner = this;
                visualizarArtista.ShowDialog();
            }
        }

        private void btnAñadir_Click(object sender, RoutedEventArgs e)
        {
            AñadirArtista añadirArtista = new AñadirArtista(usuarioActual, eventos);
            añadirArtista.Owner = this;
            añadirArtista.ShowDialog();
        }

        private void btnEliminar_Click(object sender, RoutedEventArgs e)
        {
            Artista artistaSeleccionado = (Artista)ArtistListBox.SelectedItem;

            if (artistaSeleccionado != null)
            {
                MessageBoxResult resultado = MessageBox.Show(
                    $"¿Estás seguro de que deseas eliminar al artista \"{artistaSeleccionado.Nombre} {artistaSeleccionado.Apellidos}\"?",
                    "Confirmar eliminación",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (resultado == MessageBoxResult.Yes)
                {
                    RemoveArtista(artistaSeleccionado);
                }
            }
            else
            {
                MessageBox.Show("Selecciona un artista para eliminar.", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void btnModificar_Click(object sender, RoutedEventArgs e)
        {
            Artista artistaSeleccionado = (Artista)ArtistListBox.SelectedItem;
            if (artistaSeleccionado != null)
            {
                AñadirArtista añadirArtista = new AñadirArtista(usuarioActual, eventos, artistaSeleccionado);
                añadirArtista.Owner = this;
                añadirArtista.ShowDialog();
            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }
        private void ConfigurarMenuUsuario()
        {
            btnUsuario.ContextMenu = new ContextMenu();

            var panel = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Margin = new Thickness(10),
                HorizontalAlignment = HorizontalAlignment.Center
            };

            var img = new Image
            {
                Source = new BitmapImage(new Uri("perfil-de-usuario.jpg", UriKind.Relative)),
                Width = 80,
                Height = 80,
                Margin = new Thickness(0, 0, 0, 5),
                HorizontalAlignment = HorizontalAlignment.Center
            };

            var txtNombre = new TextBlock
            {
                Text = usuarioActual.nombre,
                FontWeight = FontWeights.Bold,
                FontSize = 14,
                Margin = new Thickness(0, 0, 0, 2),
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center
            };

            var txtCorreo = new TextBlock
            {
                Text = usuarioActual.correo,
                FontSize = 12,
                Foreground = Brushes.Gray,
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center
            };

            panel.Children.Add(img);
            panel.Children.Add(txtNombre);
            panel.Children.Add(txtCorreo);

            var menuItem = new MenuItem
            {
                Header = panel
            };

            btnUsuario.ContextMenu.Items.Add(menuItem);
        }
    }
}
